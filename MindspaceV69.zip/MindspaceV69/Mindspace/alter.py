import sqlite3

# Connect to the database
conn = sqlite3.connect('mindspace.db')
cursor = conn.cursor()

# Add missing columns to the 'users' table
cursor.execute('''
ALTER TABLE users ADD COLUMN gender TEXT DEFAULT ''
''')

cursor.execute('''
ALTER TABLE users ADD COLUMN city TEXT DEFAULT ''
''')

cursor.execute('''
ALTER TABLE users ADD COLUMN feedback TEXT DEFAULT ''
''')

# Commit changes and close the connection
conn.commit()
conn.close()

print("Columns added successfully.")
