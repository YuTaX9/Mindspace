from flask import Flask, request, render_template, redirect, url_for, session, flash, jsonify
import sqlite3
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session management

mood_scores = {
    "happy": 10,
    "content": 8,
    "calm": 7,
    "neutral": 5,
    "anxious": 3,
    "sad": 2,
    "depressed": 0
}

# Database connection function
def get_db_connection():
    conn = sqlite3.connect('mindspace.db')
    conn.row_factory = sqlite3.Row
    return conn




# Sign-up route with validation
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        
        if not username or not password:
            flash('Username and password cannot be empty.', 'error')
            return redirect(url_for('signup'))

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            conn.commit()
            flash('Registration successful! Please log in.', 'success')
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            flash('Username already taken. Please choose a different username.', 'error')
            return redirect(url_for('signup'))

    return render_template('signup.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['username'] = username
            return redirect(url_for('home'))
        else:
            flash('Invalid credentials, please try again.', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'username' not in session:
        return redirect('/login')  # Redirect if user is not logged in
    
    # Connect to the database
    conn = sqlite3.connect('mindspace.db')
    cursor = conn.cursor()

    if request.method == 'POST':
        # Fetch user inputs from the form
        username = request.form['username']
        password = request.form['password']
        gender = request.form['gender']
        city = request.form['city']
        feedback = request.form['feedback']

        # Update the user profile
        if password:  # Only update password if new password is provided
            cursor.execute('''
                UPDATE users
                SET password = ?, gender = ?, city = ?, feedback = ?
                WHERE username = ?
            ''', (password, gender, city, feedback, username))
        else:
            cursor.execute('''
                UPDATE users
                SET gender = ?, city = ?, feedback = ?
                WHERE username = ?
            ''', (gender, city, feedback, username))

        conn.commit()

    # Fetch the updated user details
    cursor.execute('SELECT username, gender, city, feedback FROM users WHERE username = ?', (session['username'],))
    user = cursor.fetchone()

    conn.close()

    # Render the profile page with the updated city value
    return render_template('profile.html', 
                           username=user[0], 
                           gender=user[1], 
                           city=user[2], 
                           feedback=user[3])





@app.route('/home')
def home():
    if 'username' in session:
        return render_template('index.html')
    else:
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/mood_tracker', methods=['GET', 'POST'])
def mood_tracker():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor()

    today_date = datetime.now().strftime('%Y-%m-%d')
    cursor.execute('''
        SELECT * FROM mood_entries WHERE username = ? AND date = ?
    ''', (session['username'], today_date))
    existing_entry = cursor.fetchone()

    if request.method == 'POST':
        if existing_entry:
            flash("You have already logged your mood for today.", "warning")
            return redirect(url_for('mood_tracker'))

        mood = request.form['mood']
        date = today_date

        cursor.execute('''
            INSERT INTO mood_entries (username, mood, date)
            VALUES (?, ?, ?)
        ''', (session['username'], mood, date))
        conn.commit()

        return redirect(url_for('mood_tracker'))

    one_week_ago = datetime.now() - timedelta(days=7)
    cursor.execute('''
        SELECT date, mood FROM mood_entries WHERE username = ? ORDER BY date ASC
    ''', (session['username'],))
    mood_entries = [{'date': row[0], 'mood': row[1]} for row in cursor.fetchall()]
    conn.close()

    mood_values = [mood_scores.get(entry['mood'], 0) for entry in mood_entries if datetime.strptime(entry['date'], '%Y-%m-%d') >= one_week_ago]
    weekly_average = sum(mood_values) / len(mood_values) if mood_values else 0

    can_delete = mood_entries and datetime.strptime(mood_entries[0]['date'], '%Y-%m-%d') <= one_week_ago

    return render_template('mood_tracker.html', mood_entries=mood_entries, weekly_average=weekly_average, can_delete=can_delete)

@app.route('/delete_mood_log', methods=['POST'])
def delete_mood_log():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        DELETE FROM mood_entries WHERE username = ?
    ''', (session['username'],))
    conn.commit()
    conn.close()

    return redirect(url_for('mood_tracker'))

@app.route('/self_help')
def self_help():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('self_help.html')

@app.route('/resource_library')
def resource_library():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('resource_library.html')

@app.route('/crisis_assistance')
def crisis_assistance():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('crisis_assistance.html')

@app.route('/forum', methods=['GET', 'POST'])
def forum():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        content = request.form['content'].strip()
        parent_id = request.form.get('parent_id', 0)

        if not content:
            flash('Post content cannot be empty.', 'error')
            return redirect(url_for('forum'))

        date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute('''
            INSERT INTO forum_posts (username, content, date, parent_id)
            VALUES (?, ?, ?, ?)
        ''', (session['username'], content, date, parent_id))
        conn.commit()
        return redirect(url_for('forum'))

    cursor.execute('''
        SELECT id, username, content, date, parent_id FROM forum_posts ORDER BY date DESC
    ''')
    posts = cursor.fetchall()

    def get_replies(post_id):
        cursor.execute('''
            SELECT username, content, date FROM forum_posts WHERE parent_id = ? ORDER BY date ASC
        ''', (post_id,))
        return [{'username': row[0], 'content': row[1], 'date': row[2]} for row in cursor.fetchall()]

    posts_with_replies = []
    for post in posts:
        if post['parent_id'] == 0:
            replies = get_replies(post['id'])
            posts_with_replies.append({
                'id': post['id'],
                'username': post['username'],
                'content': post['content'],
                'date': post['date'],
                'replies': replies
            })

    conn.close()
    return render_template('forum.html', posts=posts_with_replies)

@app.route('/add_goal', methods=['POST'])
def add_goal():
    data = request.get_json()
    goal = data.get('goal')
    if goal:
        # Add the goal to your data store here
        return jsonify(success=True)
    return jsonify(success=False)

@app.route('/get_goals', methods=['GET'])
def get_goals():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    SELECT goal, date FROM goals WHERE username = ? ORDER BY date DESC
    ''', (session['username'],))
    goals = cursor.fetchall()
    conn.close()

    return jsonify([{'goal': goal['goal'], 'date': goal['date']} for goal in goals])


if __name__ == '__main__':
    app.run(debug=True)
