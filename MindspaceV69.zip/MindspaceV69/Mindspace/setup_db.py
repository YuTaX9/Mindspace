import sqlite3

# Connect to the database (or create it if it doesn't exist)
conn = sqlite3.connect('mindspace.db')
cursor = conn.cursor()

# Create users table and insert sample data
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
''')

cursor.execute('''
INSERT OR IGNORE INTO users (username, password)
VALUES ('user', 'password')
''')

# Create mood_entries table
cursor.execute('''
CREATE TABLE IF NOT EXISTS mood_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    mood TEXT NOT NULL,
    date TEXT NOT NULL
)
''')

# Create forum_posts table with parent_id column
cursor.execute('''
CREATE TABLE IF NOT EXISTS forum_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    content TEXT NOT NULL,
    date TEXT NOT NULL,
    parent_id INTEGER,
    FOREIGN KEY (parent_id) REFERENCES forum_posts(id)
)
''')

# Create goals table
cursor.execute('''
CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    goal TEXT NOT NULL,
    date TEXT NOT NULL,
    FOREIGN KEY (username) REFERENCES users(username)
)
''')

# Commit changes and close the connection
conn.commit()
conn.close()

print("Database setup complete.")
