document.getElementById("start-breathing").addEventListener("click", function () {
    const instructions = document.getElementById("breathing-instructions");
    instructions.textContent = "Inhale... Hold... Exhale...";
    setTimeout(() => instructions.textContent = "Repeat the process.", 5000);
});

// Validate Sign-Up form
document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', (event) => {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            
            if (!username || !password) {
                alert("Username and password cannot be empty.");
                event.preventDefault();
            }
        });
    }

    const forumForm = document.getElementById('forum-form');
    if (forumForm) {
        forumForm.addEventListener('submit', (event) => {
            const content = document.getElementById('content').value.trim();
            
            if (!content) {
                alert("Post content cannot be empty.");
                event.preventDefault();
            }
        });
    }
});

document.addEventListener("DOMContentLoaded", function () {
    // Check if we're on the mood tracker page
    const moodChartCanvas = document.getElementById("moodChart");
    if (moodChartCanvas) {
        // Prepare the mood data
        const moodData = JSON.parse(moodChartCanvas.dataset.moodData);

        const labels = moodData.map(entry => entry.date); // Dates for the x-axis
        const moodValues = moodData.map(entry => {
            // Convert mood strings to numeric values for plotting
            switch (entry.mood) {
                case 'happy': return 3;
                case 'neutral': return 2;
                case 'sad': return 1;
                default: return 0;
            }
        });

        // Create the line chart
        new Chart(moodChartCanvas, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Mood Trend',
                    data: moodValues,
                    borderColor: '#4a90e2',
                    fill: false,
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            callback: function (value) {
                                return ['Sad', 'Neutral', 'Happy'][value - 1] || '';
                            }
                        }
                    }
                }
            }
        });
    }
});

// SEARCH SECTION
function filterArticles() {
    const searchInput = document.getElementById('search-bar').value.toLowerCase();
    const articles = document.querySelectorAll('.article-card');
    
    articles.forEach(article => {
        const title = article.querySelector('h3').textContent.toLowerCase();
        const description = article.querySelector('p').textContent.toLowerCase();
        if (title.includes(searchInput) || description.includes(searchInput)) {
            article.style.display = "block";
        } else {
            article.style.display = "none";
        }
    });
}

// SELF HELP

// Progressive Muscle Relaxation Exercise

// Initialize Quill editor
var quill = new Quill('#editor-container', { theme: 'snow' });
document.getElementById('forum-form').onsubmit = function() {
    document.getElementById('content').value = quill.root.innerHTML;
};

